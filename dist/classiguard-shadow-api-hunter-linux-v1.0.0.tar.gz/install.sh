#!/bin/bash
# ==============================================================================
# ClassiGuard Shadow API Hunter — Linux Sensor Fleet Installer (Zero-Dependency)
# ==============================================================================
set -euo pipefail

echo "==============================================================================="
echo "   ClassiGuard Shadow API Hunter — Linux Sensor Fleet Installer (POC)          "
echo "   Zero Runtime Dependency | Self-Contained Deployment                         "
echo "==============================================================================="
echo ""

# Check for root
if [ "$(id -u)" -ne 0 ]; then
    echo "[ERROR] This installer must be run as root (or with sudo)." >&2
    echo "Usage: sudo ./install.sh" >&2
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_SRC="$SCRIPT_DIR/bin"
SYSTEMD_SRC="$SCRIPT_DIR/systemd"

INSTALL_PREFIX="/opt/classiguard"
BIN_DIR="$INSTALL_PREFIX/bin"
CONF_DIR="/etc/classiguard"
SPOOL_DIR="/var/spool/classiguard"
LOG_DIR="/var/log/classiguard"

echo "[1/5] Provisioning system directories..."
mkdir -p "$BIN_DIR" "$CONF_DIR" "$SPOOL_DIR" "$LOG_DIR"

echo "[2/5] Creating service group and user (shadowapi)..."
if ! getent group shadowapi >/dev/null; then
    groupadd --system shadowapi
fi
if ! getent passwd shadowapi >/dev/null; then
    useradd --system --gid shadowapi --home-dir /var/spool/classiguard --shell /sbin/nologin shadowapi
fi

echo "[3/5] Installing self-contained native binaries..."
if [ -d "$BIN_SRC" ]; then
    cp -f "$BIN_SRC"/* "$BIN_DIR/"
    chmod 0755 "$BIN_DIR"/*
    chown -R root:root "$BIN_DIR"
fi

echo "[4/5] Setting secure filesystem permissions..."
chown -R shadowapi:shadowapi "$CONF_DIR" "$SPOOL_DIR" "$LOG_DIR"
chmod 0750 "$CONF_DIR"
chmod 0700 "$SPOOL_DIR"
chmod 0750 "$LOG_DIR"

echo "[5/5] Registering and starting systemd services..."
if [ -d "$SYSTEMD_SRC" ]; then
    cp -f "$SYSTEMD_SRC"/*.service /etc/systemd/system/
    systemctl daemon-reload
    
    # Enable and start core sensor daemons
    for svc in shadowapi-collector shadowapi-ingest shadowapi-spool shadowapi-session shadowapi-inventory shadowapi-risk shadowapi-policy shadowapi-health; do
        if systemctl list-unit-files | grep -q "$svc"; then
            systemctl enable "$svc" >/dev/null 2>&1 || true
            systemctl restart "$svc" >/dev/null 2>&1 || true
            echo "  [STARTED] $svc.service"
        fi
    done
fi

echo ""
echo "==============================================================================="
echo "   SUCCESS: ClassiGuard Shadow API Hunter Sensor Fleet is installed!           "
echo "   Status:  systemctl status 'shadowapi-*'                                     "
echo "   Health:  curl -s http://127.0.0.1:9112/api/v1/health/node                   "
echo "==============================================================================="
