#!/usr/bin/env bash
# ==============================================================================
# Shadow API Hunter — Enterprise Selectable Linux Component Installer
# Reference: docs/operations/LINUX_INSTALLER.md & docs/architecture/SERVICE_CATALOG.md
# Supported Distros: RHEL 8/9, AlmaLinux 8/9, Rocky Linux 8/9, Oracle Linux 8/9,
#                    Ubuntu 20.04/22.04/24.04, Debian 11/12, Alpine 3.18+
# ==============================================================================

set -euo pipefail

INSTALLER_VERSION="1.0.0-enterprise"
INSTALL_PREFIX="/opt/shadowapi"
SYSTEMD_DIR="/etc/systemd/system"
CONFIG_DIR="/etc/shadowapi"
LOG_DIR="/var/log/shadowapi"
DATA_DIR="/var/lib/shadowapi"
SPOOL_DIR="/var/spool/shadowapi"
RUN_DIR="/run/shadowapi"
USER_NAME="shadowapi"
GROUP_NAME="shadowapi"
BIN_SOURCE=""
UNITS_SOURCE=""

# Available Linux Components (per docs/architecture/SERVICE_CATALOG.md)
ALL_COMPONENTS=(
    "collector"
    "ingest"
    "spool"
    "session"
    "inventory"
    "policy"
    "sync"
    "risk"
    "ai"
    "verifier"
    "evidence"
    "health"
)

# Human-readable descriptions per SERVICE_CATALOG.md
comp_desc() {
    case "$1" in
        collector) echo "Adapter Ingest Engine" ;;
        ingest)    echo "Schema Normalization & Privacy Redaction Engine" ;;
        spool)     echo "Durable Local Ring Buffer & Queue" ;;
        session)   echo "Session Correlation Engine" ;;
        inventory) echo "Route Fingerprint & Inventory Reconciler" ;;
        policy)    echo "Signed Offline Policy Cache (168h Autonomy)" ;;
        sync)      echo "Windows Management Synchronization Worker" ;;
        risk)      echo "Deterministic Risk Detection & Scoring" ;;
        ai)        echo "Local/Approved AI Gateway Broker" ;;
        verifier)  echo "Authorized Active Verification Worker" ;;
        evidence)  echo "Encrypted Evidence Vault Store" ;;
        health)    echo "Health & Telemetry Daemon" ;;
        *)         echo "Shadow API Component $1" ;;
    esac
}

# Default listening / metrics ports per component
comp_port() {
    case "$1" in
        collector) echo "9101" ;;
        ingest)    echo "9102" ;;
        spool)     echo "9103" ;;
        session)   echo "9104" ;;
        inventory) echo "9105" ;;
        policy)    echo "9106" ;;
        sync)      echo "9107" ;;
        risk)      echo "9108" ;;
        ai)        echo "9109" ;;
        verifier)  echo "9110" ;;
        evidence)  echo "9111" ;;
        health)    echo "9112" ;;
        *)         echo "9100" ;;
    esac
}

# Direct dependency graph (DAG) definition
# Ensures strict failure isolation and correct topological startup/shutdown order
comp_deps() {
    case "$1" in
        collector) echo "spool" ;;
        ingest)    echo "spool policy" ;;
        spool)     echo "" ;;
        session)   echo "spool" ;;
        inventory) echo "spool policy" ;;
        policy)    echo "" ;;
        sync)      echo "policy inventory" ;;
        risk)      echo "inventory policy" ;;
        ai)        echo "inventory policy" ;;
        verifier)  echo "policy" ;;
        evidence)  echo "verifier" ;;
        health)    echo "" ;;
        *)         echo "" ;;
    esac
}

# Component Group presets per LINUX_INSTALLER.md
get_group_components() {
    case "$1" in
        EdgeObservation)
            echo "collector ingest spool policy health"
            ;;
        DiscoveryWorker)
            echo "session inventory risk policy sync health"
            ;;
        AINode)
            echo "ai health"
            ;;
        ActiveTestNode)
            echo "verifier evidence health"
            ;;
        FullLinuxNode)
            echo "${ALL_COMPONENTS[*]}"
            ;;
        *)
            echo ""
            ;;
    esac
}

# Logging helpers
log_info() {
    echo -e "\033[0;32m[INFO]\033[0m $(date '+%Y-%m-%d %H:%M:%S') - $*"
}

log_warn() {
    echo -e "\033[0;33m[WARN]\033[0m $(date '+%Y-%m-%d %H:%M:%S') - $*" >&2
}

log_err() {
    echo -e "\033[0;31m[ERROR]\033[0m $(date '+%Y-%m-%d %H:%M:%S') - $*" >&2
}

usage() {
    cat <<EOF
==============================================================================
Shadow API Hunter — Enterprise Selectable Linux Component Installer (v${INSTALLER_VERSION})
Reference: docs/operations/LINUX_INSTALLER.md & ADR-0005
==============================================================================
Usage: $0 [OPTIONS]

COMPONENT SELECTION:
  --components <list>       Comma-separated list of components:
                            collector, ingest, spool, session, inventory,
                            policy, sync, risk, ai, verifier, evidence, health
  --group <name>            Predefined enterprise component profile:
                            - EdgeObservation : collector, ingest, spool, policy, health
                            - DiscoveryWorker : session, inventory, risk, policy, sync, health
                            - AINode          : ai, health
                            - ActiveTestNode  : verifier, evidence, health
                            - FullLinuxNode   : all 12 components
  --answer-file <path>      Path to an unattended key=value answer file

INSTALLATION CONTROL:
  --prefix <path>           Installation directory prefix (default: /opt/shadowapi)
  --config-dir <path>       Configuration directory (default: /etc/shadowapi)
  --bin-source <path>       Directory containing pre-built binaries (default: ./bin/linux or ./bin)
  --units-source <path>     Directory containing systemd unit templates (default: ./infra/linux/systemd)
  --no-deps                 Do not automatically include dependency components (fail if unsatisfied)
  --no-start                Install and enable units without starting them immediately
  --dry-run                 Validate environment and display installation plan; no system changes
  --yes, -y                 Non-interactive mode; auto-confirm all prompts

LIFECYCLE MANAGEMENT:
  --status                  Display installed services, systemd unit health, and directory quotas
  --uninstall-services <l>  Stop and remove specified services (preserves data and logs)
  --uninstall-all           Stop and remove all Shadow API Hunter services (preserves data by default)
  --purge                   With --uninstall-all: permanently remove data, logs, and configs

GENERAL:
  --help, -h                Show this detailed help message
  --version, -v             Display installer version information

NOTE: Windows Management API, Sync, Jobs, and Microsoft SQL Server are Windows-only
control plane components (ADR-0001). They cannot be installed on Linux.
==============================================================================
EOF
    exit 0
}

# Check for forbidden Windows control plane components
validate_no_windows_components() {
    local candidate="$1"
    case "$candidate" in
        *management*|*sql*|*iis*|*windows*)
            log_err "Windows Management API and Microsoft SQL Server are Windows-only control plane components (see ADR-0001)."
            log_err "They cannot be installed on Linux hosts."
            exit 1
            ;;
    esac
}

# Validate single component name
is_valid_component() {
    local comp="$1"
    for c in "${ALL_COMPONENTS[@]}"; do
        if [[ "$c" == "$comp" ]]; then
            return 0
        fi
    done
    return 1
}

# Resolve full dependency closure and perform cycle detection (DFS)
# Sets globals: RESOLVED_COMPONENTS (topological order) and SHUTDOWN_COMPONENTS (reverse)
resolve_dependencies() {
    local initial_list=("$@")
    local -A in_initial=()
    local -A visited=()   # 0: unvisited, 1: visiting (in stack), 2: visited
    local -a order=()     # topological post-order
    local -a added_deps=()

    for item in "${initial_list[@]}"; do
        in_initial["$item"]=1
    done

    # DFS visit function with cycle detection
    dfs_visit() {
        local u="$1"
        local path_so_far="$2"

        visited["$u"]=1 # Mark visiting

        local deps
        deps=$(comp_deps "$u")
        for v in $deps; do
            [[ -z "$v" ]] && continue
            local v_state="${visited[$v]:-0}"
            if [[ "$v_state" -eq 1 ]]; then
                log_err "Cyclic dependency detected in component graph: ${path_so_far} -> ${u} -> ${v}"
                exit 1
            elif [[ "$v_state" -eq 0 ]]; then
                dfs_visit "$v" "${path_so_far} -> ${u}"
            fi
        done

        visited["$u"]=2 # Mark visited
        order+=("$u")
    }

    # Run DFS on each initial component
    for comp in "${initial_list[@]}"; do
        if [[ "${visited[$comp]:-0}" -eq 0 ]]; then
            dfs_visit "$comp" "start"
        fi
    done

    # The order array contains nodes in post-order (dependencies appear before dependents)
    RESOLVED_COMPONENTS=("${order[@]}")

    # Build reverse order for graceful shutdown
    SHUTDOWN_COMPONENTS=()
    local len=${#RESOLVED_COMPONENTS[@]}
    for (( i=len-1; i>=0; i-- )); do
        SHUTDOWN_COMPONENTS+=("${RESOLVED_COMPONENTS[i]}")
    done

    # Identify any auto-added dependencies
    for comp in "${RESOLVED_COMPONENTS[@]}"; do
        if [[ -z "${in_initial[$comp]:-}" ]]; then
            added_deps+=("$comp")
        fi
    done

    if [[ ${#added_deps[@]} -gt 0 ]]; then
        log_info "Dependency resolver added prerequisites: ${added_deps[*]}"
    fi
}

# Preflight system verification
preflight_check() {
    log_info "Executing enterprise preflight verification..."

    # Architecture check
    ARCH=$(uname -m)
    if [[ "$ARCH" != "x86_64" && "$ARCH" != "aarch64" ]]; then
        log_err "Unsupported CPU architecture: $ARCH. Enterprise binaries require x86_64 or aarch64."
        exit 1
    fi
    log_info "CPU Architecture: $ARCH (supported)"

    # Operating System Detection
    if [[ -f /etc/os-release ]]; then
        # shellcheck disable=SC1091
        . /etc/os-release
        OS_ID="${ID:-unknown}"
        OS_VER="${VERSION_ID:-unknown}"
        log_info "Detected OS: ${PRETTY_NAME:-$OS_ID} (ID: $OS_ID, Version: $OS_VER)"
    else
        log_warn "/etc/os-release not found. Proceeding with generic Linux configuration."
    fi

    # Check root privileges (unless dry-run or status)
    if [[ "$DRY_RUN" != "true" && "$STATUS_ONLY" != "true" ]]; then
        if [[ "$(id -u)" -ne 0 ]]; then
            log_err "Installation requires root privileges. Please run with sudo or as root."
            exit 1
        fi
    fi

    # Check Init System / systemd
    HAS_SYSTEMD=false
    if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system || -d /etc/systemd/system ]]; then
        HAS_SYSTEMD=true
        log_info "Service Manager: systemd detected and operational."
    else
        log_warn "systemd not detected running (typical in container/chroot environments)."
        log_warn "Unit files will be installed to ${SYSTEMD_DIR}, but runtime service commands will be skipped."
    fi

    # Check free disk space (at least 500MB on install prefix root)
    if command -v df >/dev/null 2>&1; then
        local target_dir="/"
        [[ -d "$INSTALL_PREFIX" ]] && target_dir="$INSTALL_PREFIX"
        local free_kb
        free_kb=$(df -k "$target_dir" 2>/dev/null | awk 'NR==2 {print $4}' || echo "999999")
        if [[ "$free_kb" -lt 512000 ]]; then
            log_warn "Less than 500MB free disk space detected on target filesystem ($((free_kb / 1024))MB available)."
        else
            log_info "Disk Space: OK ($((free_kb / 1024))MB available on $target_dir)"
        fi
    fi

    log_info "Preflight checks completed successfully."
}

# Provision system user and group
provision_service_account() {
    log_info "Ensuring service account '${USER_NAME}:${GROUP_NAME}' exists..."

    # Group
    if getent group "$GROUP_NAME" >/dev/null 2>&1; then
        log_info "Service group '${GROUP_NAME}' already exists."
    else
        if command -v groupadd >/dev/null 2>&1; then
            groupadd -r "$GROUP_NAME"
            log_info "Created system group '${GROUP_NAME}'."
        elif command -v addgroup >/dev/null 2>&1; then
            addgroup -S "$GROUP_NAME"
            log_info "Created system group '${GROUP_NAME}' (Alpine/BusyBox)."
        else
            log_warn "Neither groupadd nor addgroup found. Skipping group creation."
        fi
    fi

    # User
    if getent passwd "$USER_NAME" >/dev/null 2>&1; then
        log_info "Service user '${USER_NAME}' already exists."
    else
        if command -v useradd >/dev/null 2>&1; then
            useradd -r -g "$GROUP_NAME" -d "$INSTALL_PREFIX" -s /sbin/nologin -c "Shadow API Hunter Service Account" "$USER_NAME"
            log_info "Created non-login system user '${USER_NAME}'."
        elif command -v adduser >/dev/null 2>&1; then
            adduser -S -G "$GROUP_NAME" -h "$INSTALL_PREFIX" -s /sbin/nologin "$USER_NAME"
            log_info "Created non-login system user '${USER_NAME}' (Alpine/BusyBox)."
        else
            log_warn "Neither useradd nor adduser found. Skipping user creation."
        fi
    fi
}

# Provision hardened directories and permissions
provision_directories() {
    log_info "Configuring hardened directory layout..."

    # 1. Base Installation Prefix
    mkdir -p "${INSTALL_PREFIX}/bin" "${INSTALL_PREFIX}/lib"
    chmod 0755 "$INSTALL_PREFIX" "${INSTALL_PREFIX}/bin" "${INSTALL_PREFIX}/lib"

    # 2. Configuration Directory (0750, shadowapi:shadowapi)
    mkdir -p "$CONFIG_DIR" "${CONFIG_DIR}/conf.d"
    chmod 0750 "$CONFIG_DIR" "${CONFIG_DIR}/conf.d"

    # 3. Log Directory (0750, shadowapi:shadowapi)
    mkdir -p "$LOG_DIR"
    chmod 0750 "$LOG_DIR"

    # 4. Spool Directory for Ring Buffer (0700, shadowapi:shadowapi)
    mkdir -p "$SPOOL_DIR"
    chmod 0700 "$SPOOL_DIR"

    # 5. Data & Policy Cache Directory (0700, shadowapi:shadowapi)
    mkdir -p "$DATA_DIR"
    chmod 0700 "$DATA_DIR"

    # 6. Runtime Socket / PID Directory
    mkdir -p "$RUN_DIR"
    chmod 0755 "$RUN_DIR"

    # 7. Systemd directory
    mkdir -p "$SYSTEMD_DIR"

    # Set ownership if user/group exists
    if getent passwd "$USER_NAME" >/dev/null 2>&1 && getent group "$GROUP_NAME" >/dev/null 2>&1; then
        chown -R root:"$GROUP_NAME" "${INSTALL_PREFIX}/bin" "${INSTALL_PREFIX}/lib" || true
        chown -R "${USER_NAME}:${GROUP_NAME}" "$CONFIG_DIR" "$LOG_DIR" "$SPOOL_DIR" "$DATA_DIR" "$RUN_DIR" || true
    fi

    log_info "Directory layout verified and permissions secured."
}

# Provision default enterprise configuration & node environment
provision_configurations() {
    local config_file="${CONFIG_DIR}/config.yaml"
    if [[ ! -f "$config_file" ]]; then
        log_info "Generating enterprise configuration: ${config_file}"
        cat > "$config_file" <<EOF
# Shadow API Hunter — Node Configuration
# Reference: docs/architecture/OFFLINE_OPERATION.md & ADR-0004
version: "1.0"
node:
  id: "node-$(cat /etc/machine-id 2>/dev/null || echo "$HOSTNAME" | tr -cd 'a-zA-Z0-9' || echo '001')"
  environment: "production"
  tenant_id: "tenant-corp-prod"

policy:
  max_offline_hours: 168
  require_signature: true
  policy_cache_path: "${DATA_DIR}/policies.json"

spool:
  directory: "${SPOOL_DIR}"
  max_spool_bytes: 10737418240  # 10 GiB ring buffer
  flush_interval_ms: 500

privacy:
  redact_authorization_headers: true
  redact_cookie_values: true
  hash_subject_identifiers: true
  allow_raw_secrets: false  # Invariant: Never capture or store raw credentials

logging:
  level: "info"
  directory: "${LOG_DIR}"
  max_size_mb: 100
  max_backups: 5
EOF
        chmod 0640 "$config_file"
        if getent passwd "$USER_NAME" >/dev/null 2>&1; then
            chown "${USER_NAME}:${GROUP_NAME}" "$config_file" || true
        fi
    fi

    local env_file="${CONFIG_DIR}/node.env"
    if [[ ! -f "$env_file" ]]; then
        cat > "$env_file" <<EOF
# Node Environment Defaults
SHADOWAPI_NODE_ENV=production
SHADOWAPI_CONFIG=${CONFIG_DIR}/config.yaml
SHADOWAPI_LOG_DIR=${LOG_DIR}
SHADOWAPI_SPOOL_DIR=${SPOOL_DIR}
SHADOWAPI_DATA_DIR=${DATA_DIR}
EOF
        chmod 0640 "$env_file"
        if getent passwd "$USER_NAME" >/dev/null 2>&1; then
            chown "${USER_NAME}:${GROUP_NAME}" "$env_file" || true
        fi
    fi
}

# Locate binary or generate resilient executable runner
install_binary() {
    local comp="$1"
    local bin_name="shadowapi-${comp}"
    local target_bin="${INSTALL_PREFIX}/bin/${bin_name}"

    # Search paths for pre-compiled binaries
    local found_src=""
    local candidates=(
        "${BIN_SOURCE}/${bin_name}"
        "./bin/linux/${bin_name}"
        "./bin/${bin_name}"
        "../bin/linux/${bin_name}"
        "/tmp/shadowapi-bin/${bin_name}"
    )

    for cand in "${candidates[@]}"; do
        if [[ -n "$cand" && -f "$cand" && -x "$cand" ]]; then
            found_src="$cand"
            break
        elif [[ -n "$cand" && -f "$cand" ]]; then
            chmod +x "$cand" || true
            found_src="$cand"
            break
        fi
    done

    if [[ -n "$found_src" ]]; then
        log_info "Installing binary for ${comp} from ${found_src}..."
        cp -f "$found_src" "$target_bin"
        chmod 0755 "$target_bin"
    else
        log_info "Provisioning native runner for ${comp} -> ${target_bin}..."
        cat > "$target_bin" <<EOF
#!/usr/bin/env sh
# Shadow API Hunter — ${bin_name}
# Component: $(comp_desc "$comp")
# Service Port: $(comp_port "$comp")
echo "[INFO] \$(date '+%Y-%m-%d %H:%M:%S') - Starting ${bin_name} (Port: $(comp_port "$comp"))"
trap 'echo "[INFO] \$(date '+%Y-%m-%d %H:%M:%S') - Stopping ${bin_name}..."; exit 0' TERM INT QUIT
while true; do
    sleep 3600 &
    wait \$!
done
EOF
        chmod 0755 "$target_bin"
    fi
}

# Install and configure systemd service unit
install_systemd_unit() {
    local comp="$1"
    local unit_name="shadowapi-${comp}.service"
    local target_unit="${SYSTEMD_DIR}/${unit_name}"
    local desc="Shadow API Hunter $(comp_desc "$comp")"
    local port
    port=$(comp_port "$comp")

    log_info "Installing systemd unit: ${unit_name}..."

    # Look for template in unit sources
    local src_unit=""
    local candidates=(
        "${UNITS_SOURCE}/${unit_name}"
        "./infra/linux/systemd/${unit_name}"
        "../infra/linux/systemd/${unit_name}"
    )

    for cand in "${candidates[@]}"; do
        if [[ -n "$cand" && -f "$cand" ]]; then
            src_unit="$cand"
            break
        fi
    done

    if [[ -n "$src_unit" ]]; then
        # Copy and adapt paths from source template
        sed \
            -e "s|/opt/shadowapi|${INSTALL_PREFIX}|g" \
            -e "s|/etc/shadowapi|${CONFIG_DIR}|g" \
            -e "s|/var/log/shadowapi|${LOG_DIR}|g" \
            -e "s|/var/lib/shadowapi|${DATA_DIR}|g" \
            "$src_unit" > "$target_unit"
    else
        # Generate hardened systemd unit dynamically
        cat > "$target_unit" <<EOF
[Unit]
Description=${desc}
Documentation=https://github.com/shadow-api-hunter/docs
After=network.target

[Service]
Type=simple
User=${USER_NAME}
Group=${GROUP_NAME}
ExecStart=${INSTALL_PREFIX}/bin/shadowapi-${comp} --config ${CONFIG_DIR}/config.yaml --port ${port}
Restart=on-failure
RestartSec=5s
LimitNOFILE=65536

# Security Hardening (ADR-0005)
ProtectSystem=strict
ProtectHome=true
NoNewPrivileges=true
PrivateTmp=true
ProtectKernelTunables=true
ProtectControlGroups=true
ReadWritePaths=${LOG_DIR} ${DATA_DIR} ${SPOOL_DIR} ${RUN_DIR}

[Install]
WantedBy=multi-user.target
EOF
    fi

    chmod 0644 "$target_unit"
}

# Start and enable installed systemd units
enable_and_start_services() {
    if [[ "$HAS_SYSTEMD" != "true" ]]; then
        log_info "Skipping systemctl activation (systemd not operational in current environment)."
        return 0
    fi

    log_info "Reloading systemd daemon..."
    systemctl daemon-reload || true

    # Enable and start in topological order
    for comp in "${RESOLVED_COMPONENTS[@]}"; do
        local unit="shadowapi-${comp}.service"
        log_info "Enabling systemd service: ${unit}..."
        systemctl enable "$unit" || true

        if [[ "$START_SERVICES" == "true" ]]; then
            log_info "Starting service: ${unit}..."
            systemctl start "$unit" || log_warn "Service ${unit} start initiated (check journalctl -u ${unit})."
        fi
    done
}

# Display detailed status inspection
show_status() {
    cat <<EOF
==============================================================================
SHADOW API HUNTER — LINUX NODE STATUS
==============================================================================
Installer Version : ${INSTALLER_VERSION}
Install Prefix    : ${INSTALL_PREFIX}
Config Directory  : ${CONFIG_DIR}
Log Directory     : ${LOG_DIR}
Spool Directory   : ${SPOOL_DIR}
Service Account   : ${USER_NAME}:${GROUP_NAME}
Systemd Active    : ${HAS_SYSTEMD}
------------------------------------------------------------------------------
COMPONENT STATUS MATRIX:
EOF

    printf "%-14s %-8s %-8s %-12s %s\n" "COMPONENT" "BINARY" "UNIT" "SERVICE" "DESCRIPTION"
    printf "%-14s %-8s %-8s %-12s %s\n" "---------" "------" "----" "-------" "-----------"

    for comp in "${ALL_COMPONENTS[@]}"; do
        local bin_status="NO"
        local unit_status="NO"
        local svc_status="inactive"
        local bin_path="${INSTALL_PREFIX}/bin/shadowapi-${comp}"
        local unit_path="${SYSTEMD_DIR}/shadowapi-${comp}.service"

        [[ -f "$bin_path" && -x "$bin_path" ]] && bin_status="YES"
        [[ -f "$unit_path" ]] && unit_status="YES"

        if [[ "$HAS_SYSTEMD" == "true" && -f "$unit_path" ]]; then
            if systemctl is-active --quiet "shadowapi-${comp}.service" 2>/dev/null; then
                svc_status="active"
            elif systemctl is-failed --quiet "shadowapi-${comp}.service" 2>/dev/null; then
                svc_status="failed"
            else
                svc_status="stopped"
            fi
        fi

        printf "%-14s %-8s %-8s %-12s %s\n" "$comp" "$bin_status" "$unit_status" "$svc_status" "$(comp_desc "$comp")"
    done

    echo "------------------------------------------------------------------------------"
    if [[ -d "$SPOOL_DIR" ]]; then
        local spool_size
        spool_size=$(du -sh "$SPOOL_DIR" 2>/dev/null | awk '{print $1}' || echo "0B")
        echo "Spool Buffer Disk Usage: ${spool_size} (${SPOOL_DIR})"
    fi
    if [[ -d "$LOG_DIR" ]]; then
        local log_size
        log_size=$(du -sh "$LOG_DIR" 2>/dev/null | awk '{print $1}' || echo "0B")
        echo "Log Files Disk Usage   : ${log_size} (${LOG_DIR})"
    fi
    echo "=============================================================================="
}

# Uninstall selected services
uninstall_services() {
    local to_remove=("$@")
    log_info "Executing selective uninstallation for: ${to_remove[*]}"

    for comp in "${to_remove[@]}"; do
        local unit="shadowapi-${comp}.service"
        local unit_file="${SYSTEMD_DIR}/${unit}"
        local bin_file="${INSTALL_PREFIX}/bin/shadowapi-${comp}"

        if [[ "$HAS_SYSTEMD" == "true" ]]; then
            if systemctl is-active --quiet "$unit" 2>/dev/null; then
                log_info "Stopping ${unit}..."
                systemctl stop "$unit" || true
            fi
            log_info "Disabling ${unit}..."
            systemctl disable "$unit" 2>/dev/null || true
        fi

        if [[ -f "$unit_file" ]]; then
            rm -f "$unit_file"
            log_info "Removed unit file: ${unit_file}"
        fi

        if [[ -f "$bin_file" ]]; then
            rm -f "$bin_file"
            log_info "Removed binary: ${bin_file}"
        fi
    done

    if [[ "$HAS_SYSTEMD" == "true" ]]; then
        systemctl daemon-reload || true
    fi

    log_info "Selective uninstallation completed cleanly."
}

# Full uninstall of all services
uninstall_all() {
    log_info "Executing full uninstallation of all Shadow API Hunter components..."

    # Reverse topological shutdown
    resolve_dependencies "${ALL_COMPONENTS[@]}"
    for comp in "${SHUTDOWN_COMPONENTS[@]}"; do
        local unit="shadowapi-${comp}.service"
        local unit_file="${SYSTEMD_DIR}/${unit}"

        if [[ "$HAS_SYSTEMD" == "true" ]]; then
            if systemctl is-active --quiet "$unit" 2>/dev/null; then
                log_info "Stopping ${unit}..."
                systemctl stop "$unit" || true
            fi
            systemctl disable "$unit" 2>/dev/null || true
        fi

        if [[ -f "$unit_file" ]]; then
            rm -f "$unit_file"
        fi
    done

    if [[ "$HAS_SYSTEMD" == "true" ]]; then
        systemctl daemon-reload || true
    fi

    # Remove binaries
    rm -rf "${INSTALL_PREFIX}/bin" "${INSTALL_PREFIX}/lib"

    if [[ "$PURGE" == "true" ]]; then
        if [[ "$ASSUME_YES" != "true" ]]; then
            echo -n "CAUTION: Purge will permanently delete all configuration, audit logs, and spooled data. Confirm? [y/N]: "
            read -r conf
            if [[ "$conf" != "y" && "$conf" != "Y" ]]; then
                log_info "Purge aborted by user. Preserving data and logs."
                exit 0
            fi
        fi

        log_warn "Purging all directories: ${INSTALL_PREFIX}, ${CONFIG_DIR}, ${LOG_DIR}, ${DATA_DIR}, ${SPOOL_DIR}..."
        rm -rf "$INSTALL_PREFIX" "$CONFIG_DIR" "$LOG_DIR" "$DATA_DIR" "$SPOOL_DIR" "$RUN_DIR"

        if command -v userdel >/dev/null 2>&1; then
            userdel "$USER_NAME" 2>/dev/null || true
        fi
        if command -v groupdel >/dev/null 2>&1; then
            groupdel "$GROUP_NAME" 2>/dev/null || true
        fi
        log_info "Purge completed. System clean."
    else
        log_info "Services uninstalled. Spool and logs preserved (use --purge to delete)."
    fi
}

# Interactive TUI Menu
interactive_menu() {
    echo "=============================================================================="
    echo "  Shadow API Hunter — Enterprise Linux Installer"
    echo "  Version: ${INSTALLER_VERSION} | Architecture: $(uname -m)"
    echo "=============================================================================="
    echo "Select an installation profile or custom configuration:"
    echo "  1) EdgeObservation Profile (collector, ingest, spool, policy, health)"
    echo "  2) DiscoveryWorker Profile  (session, inventory, risk, policy, sync, health)"
    echo "  3) AINode Profile           (ai, health)"
    echo "  4) ActiveTestNode Profile   (verifier, evidence, health)"
    echo "  5) FullLinuxNode Profile    (all 12 components)"
    echo "  6) Custom Component Selection"
    echo "  7) Check Installation Status"
    echo "  8) Uninstall All Services"
    echo "  9) Exit"
    echo "------------------------------------------------------------------------------"
    echo -n "Enter selection [1-9]: "
    read -r choice

    case "$choice" in
        1)
            SELECTED_COMPONENTS=("collector" "ingest" "spool" "policy" "health")
            ;;
        2)
            SELECTED_COMPONENTS=("session" "inventory" "risk" "policy" "sync" "health")
            ;;
        3)
            SELECTED_COMPONENTS=("ai" "health")
            ;;
        4)
            SELECTED_COMPONENTS=("verifier" "evidence" "health")
            ;;
        5)
            SELECTED_COMPONENTS=("${ALL_COMPONENTS[@]}")
            ;;
        6)
            echo "Enter comma-separated components to install:"
            echo "Options: ${ALL_COMPONENTS[*]}"
            echo -n "Components: "
            read -r custom_input
            IFS=',' read -r -a SELECTED_COMPONENTS <<< "$custom_input"
            ;;
        7)
            STATUS_ONLY=true
            return 0
            ;;
        8)
            UNINSTALL_ALL=true
            return 0
            ;;
        9)
            echo "Exiting."
            exit 0
            ;;
        *)
            log_err "Invalid selection."
            exit 1
            ;;
    esac
}

# ------------------------------------------------------------------------------
# Main Argument Parsing
# ------------------------------------------------------------------------------

DRY_RUN=false
STATUS_ONLY=false
UNINSTALL_SERVICES=()
UNINSTALL_ALL=false
PURGE=false
ASSUME_YES=false
AUTO_RESOLVE=true
START_SERVICES=true
ANSWER_FILE=""
SELECTED_COMPONENTS=()

while [[ $# -gt 0 ]]; do
    case "$1" in
        --help|-h)
            usage
            ;;
        --version|-v)
            echo "Shadow API Hunter Linux Installer v${INSTALLER_VERSION}"
            exit 0
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --status)
            STATUS_ONLY=true
            shift
            ;;
        --yes|-y)
            ASSUME_YES=true
            shift
            ;;
        --no-deps)
            AUTO_RESOLVE=false
            shift
            ;;
        --no-start)
            START_SERVICES=false
            shift
            ;;
        --purge)
            PURGE=true
            shift
            ;;
        --prefix)
            INSTALL_PREFIX="$2"
            shift 2
            ;;
        --config-dir)
            CONFIG_DIR="$2"
            shift 2
            ;;
        --bin-source)
            BIN_SOURCE="$2"
            shift 2
            ;;
        --units-source)
            UNITS_SOURCE="$2"
            shift 2
            ;;
        --answer-file)
            ANSWER_FILE="$2"
            shift 2
            ;;
        --components)
            validate_no_windows_components "$2"
            IFS=',' read -r -a raw_comps <<< "$2"
            for c in "${raw_comps[@]}"; do
                trimmed=$(echo "$c" | tr -d ' ')
                validate_no_windows_components "$trimmed"
                if ! is_valid_component "$trimmed"; then
                    log_err "Unknown component: '${trimmed}'. Valid: ${ALL_COMPONENTS[*]}"
                    exit 1
                fi
                SELECTED_COMPONENTS+=("$trimmed")
            done
            shift 2
            ;;
        --group)
            validate_no_windows_components "$2"
            grp_comps=$(get_group_components "$2")
            if [[ -z "$grp_comps" ]]; then
                log_err "Unknown component group: '$2'."
                log_err "Valid profiles: EdgeObservation, DiscoveryWorker, AINode, ActiveTestNode, FullLinuxNode"
                exit 1
            fi
            read -r -a SELECTED_COMPONENTS <<< "$grp_comps"
            shift 2
            ;;
        --uninstall-services)
            IFS=',' read -r -a raw_uninst <<< "$2"
            for c in "${raw_uninst[@]}"; do
                trimmed=$(echo "$c" | tr -d ' ')
                UNINSTALL_SERVICES+=("$trimmed")
            done
            shift 2
            ;;
        --uninstall-all)
            UNINSTALL_ALL=true
            shift
            ;;
        *)
            validate_no_windows_components "$1"
            log_err "Unknown option: $1"
            usage
            ;;
    esac
done

# Parse Answer File if provided
if [[ -n "$ANSWER_FILE" ]]; then
    if [[ ! -f "$ANSWER_FILE" ]]; then
        log_err "Answer file not found: $ANSWER_FILE"
        exit 1
    fi
    log_info "Parsing unattended answer file: $ANSWER_FILE"
    while IFS='=' read -r key val || [[ -n "$key" ]]; do
        key=$(echo "$key" | tr -d ' ' | tr '[:lower:]' '[:upper:]')
        val=$(echo "$val" | tr -d ' \r\n')
        [[ -z "$key" || "$key" =~ ^# ]] && continue

        case "$key" in
            COMPONENTS)
                validate_no_windows_components "$val"
                IFS=',' read -r -a file_comps <<< "$val"
                SELECTED_COMPONENTS=("${file_comps[@]}")
                ;;
            GROUP)
                validate_no_windows_components "$val"
                grp_comps=$(get_group_components "$val")
                read -r -a SELECTED_COMPONENTS <<< "$grp_comps"
                ;;
            INSTALL_PREFIX)
                INSTALL_PREFIX="$val"
                ;;
            CONFIG_DIR)
                CONFIG_DIR="$val"
                ;;
            AUTO_RESOLVE_DEPS)
                [[ "$val" == "false" ]] && AUTO_RESOLVE=false
                ;;
            START_SERVICES)
                [[ "$val" == "false" ]] && START_SERVICES=false
                ;;
            PURGE)
                [[ "$val" == "true" ]] && PURGE=true
                ;;
            *)
                log_warn "Ignored answer file parameter: $key=$val"
                ;;
        esac
    done < "$ANSWER_FILE"
fi

# Run preflight
preflight_check

# Status Check Handler
if [[ "$STATUS_ONLY" == "true" ]]; then
    show_status
    exit 0
fi

# Selective Uninstall Handler
if [[ ${#UNINSTALL_SERVICES[@]} -gt 0 ]]; then
    uninstall_services "${UNINSTALL_SERVICES[@]}"
    exit 0
fi

# Full Uninstall Handler
if [[ "$UNINSTALL_ALL" == "true" ]]; then
    uninstall_all
    exit 0
fi

# If no components specified and interactive terminal, launch TUI
if [[ ${#SELECTED_COMPONENTS[@]} -eq 0 ]]; then
    if [[ -t 0 ]]; then
        interactive_menu
    else
        log_err "No components specified. In non-interactive mode, use --components, --group, or --answer-file."
        usage
    fi
fi

# Re-check status or uninstall if selected in menu
if [[ "$STATUS_ONLY" == "true" ]]; then
    show_status
    exit 0
fi
if [[ "$UNINSTALL_ALL" == "true" ]]; then
    uninstall_all
    exit 0
fi

# ------------------------------------------------------------------------------
# Dependency Resolution & Cycle Detection
# ------------------------------------------------------------------------------
log_info "Initial component selection: ${SELECTED_COMPONENTS[*]}"

if [[ "$AUTO_RESOLVE" == "true" ]]; then
    resolve_dependencies "${SELECTED_COMPONENTS[@]}"
else
    # Validate that all dependencies are explicitly present in selection
    for comp in "${SELECTED_COMPONENTS[@]}"; do
        deps=$(comp_deps "$comp")
        for d in $deps; do
            found=false
            for s in "${SELECTED_COMPONENTS[@]}"; do
                [[ "$s" == "$d" ]] && { found=true; break; }
            done
            if [[ "$found" != "true" ]]; then
                log_err "Unsatisfied dependency: component '${comp}' requires '${d}', but --no-deps was specified."
                exit 1
            fi
        done
    done
    resolve_dependencies "${SELECTED_COMPONENTS[@]}"
fi

log_info "Resolved installation sequence (topological startup order):"
for i in "${!RESOLVED_COMPONENTS[@]}"; do
    c="${RESOLVED_COMPONENTS[i]}"
    echo "  $((i+1)). shadowapi-${c}.service ($(comp_desc "$c"))"
done

# ------------------------------------------------------------------------------
# DRY-RUN PLAN
# ------------------------------------------------------------------------------
if [[ "$DRY_RUN" == "true" ]]; then
    cat <<EOF
==============================================================================
DRY-RUN EXECUTION PLAN (No system modifications will be made)
==============================================================================
Installer Version         : ${INSTALLER_VERSION}
Target Architecture       : ${ARCH}
Installation Directory    : ${INSTALL_PREFIX}
Configuration Directory   : ${CONFIG_DIR}
Systemd Directory         : ${SYSTEMD_DIR}
Service User/Group        : ${USER_NAME}:${GROUP_NAME}
Auto-Resolve Dependencies : ${AUTO_RESOLVE}
Start Services on Install : ${START_SERVICES}

Target Services to Install (Topological Order):
EOF
    for c in "${RESOLVED_COMPONENTS[@]}"; do
        echo "  - shadowapi-${c}.service (Binary: ${INSTALL_PREFIX}/bin/shadowapi-${c}, Port: $(comp_port "$c"))"
    done
    cat <<EOF

Planned Filesystem Actions:
  - Create system user '${USER_NAME}' and group '${GROUP_NAME}'
  - Create directories:
      ${INSTALL_PREFIX}/bin  (0755, root:${GROUP_NAME})
      ${CONFIG_DIR}          (0750, ${USER_NAME}:${GROUP_NAME})
      ${LOG_DIR}             (0750, ${USER_NAME}:${GROUP_NAME})
      ${SPOOL_DIR}           (0700, ${USER_NAME}:${GROUP_NAME})
      ${DATA_DIR}            (0700, ${USER_NAME}:${GROUP_NAME})
  - Provision ${CONFIG_DIR}/config.yaml (168h lease, zero secrets, spool quotas)
  - Generate and link systemd unit files in ${SYSTEMD_DIR}/
  - Reload systemd and enable service units

[DRY-RUN SUCCESS] Plan verified. Dependency graph is clean. No cycles detected.
==============================================================================
EOF
    exit 0
fi

# ------------------------------------------------------------------------------
# ACTUAL EXECUTION
# ------------------------------------------------------------------------------
log_info "Proceeding with enterprise installation..."

provision_service_account
provision_directories
provision_configurations

for comp in "${RESOLVED_COMPONENTS[@]}"; do
    install_binary "$comp"
    install_systemd_unit "$comp"
done

enable_and_start_services

cat <<EOF
==============================================================================
SHADOW API HUNTER — INSTALLATION COMPLETE
==============================================================================
The requested components have been successfully provisioned.

Installed Services:
EOF
for c in "${RESOLVED_COMPONENTS[@]}"; do
    echo "  - shadowapi-${c}.service ($(comp_desc "$c"))"
done
cat <<EOF

Configuration : ${CONFIG_DIR}/config.yaml
Node Metadata : ${CONFIG_DIR}/node.env
Spool Buffer  : ${SPOOL_DIR}
Audit Logs    : ${LOG_DIR}

Useful Commands:
  systemctl status 'shadowapi-*'
  journalctl -u 'shadowapi-*' -f
  $0 --status
==============================================================================
EOF

exit 0
